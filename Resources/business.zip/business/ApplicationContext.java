
package business;

import business.category.CategoryDao;
import business.category.CategoryDaoJdbc;

// TODO: Add the appropriate code for the book DAO. 

public class ApplicationContext {

    private CategoryDao categoryDao;

    public static ApplicationContext INSTANCE = new ApplicationContext();

    private ApplicationContext() {
        categoryDao = new CategoryDaoJdbc();
    }

    public CategoryDao getCategoryDao() {
        return categoryDao;
    }
}
